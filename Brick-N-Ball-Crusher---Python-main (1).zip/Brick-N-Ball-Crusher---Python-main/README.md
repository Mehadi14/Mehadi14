# Brick-N-Ball-Crusher---Python
Brick N Ball Crusher Game, built in Python using PyGame


![Brick-N-Ball-Crusher---Python](https://media.giphy.com/media/42DHdGYzdIHEiAQo7e/giphy.gif)
